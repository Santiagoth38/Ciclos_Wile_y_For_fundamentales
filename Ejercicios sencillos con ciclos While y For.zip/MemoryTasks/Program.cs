﻿// See https://aka.ms/new-console-template for more information
Console.WriteLine("Hello, World!");



// See https://aka.ms/new-console-template for more information
Console.WriteLine("TALLER 1");

Console.WriteLine("");


/*Realizar un programa que imprima los números del 0 al 20, y que aumente de 2 en 2.
0, 2, 4, 6, .... 20.*/

Console.WriteLine("1. Realizar un programa que imprima los números del 0 al 20, y que aumente de 2 en 2. 0, 2, 4, 6, .... 20.");
Console.WriteLine("");

int i =0;

for ( i =0; i<=20; i++){


Console.Write("");
Console.Write(i+",");


}

Console.WriteLine("");
Console.WriteLine("");
for ( i =0; i<=20; i++){
if (i%2 ==0){


Console.Write(i+",");
    
}}

Console.WriteLine("");

Console.WriteLine("2. Realizar un programa que imprima los números del 20 al 1, en forma descendente. Descendiendo de 1 en 1. 20, 19, 18,...1.");
Console.WriteLine("");

for (int i2 = 20; i2>=0; i2--){

Console.Write(i2+",");

}

Console.WriteLine("");
Console.WriteLine("");
Console.WriteLine("3. Desarrollar un programa que haga un ciclo recorriendo los números del 1 al 50, de 1 en 1. Determinando cuales de esos números son pares e imprimiendo sólo aquellos que cumplen esta condición. 2, 4, 6...50.");
Console.WriteLine("");

for (int i3 =1; i3<=50; i3++){

 if(i3%2==0){

Console.Write(i3+",");

 }   
}

Console.WriteLine("");
Console.WriteLine("");

Console.WriteLine("4. Desarrollar un programa que haga un ciclo recorriendo los números del 50 al 1,decrementando de 1 en 1. Determinando cuales de esos números son impares e imprimiendo sólo aquellos que cumplen esta condición. 49, 47, 45...1.");
Console.WriteLine("");

for (int i4 =50; i4>=1; i4--){

 if(i4%2 ==1){

 
int sh = i4;

 
Console.Write(sh+",");
 }
 }


Console.WriteLine("");




 Console.WriteLine("5. Desarrollar un algoritmo que realice la sumatoria de los numeros pares,  comprendidos entre 1 y 100. Esto indica que deberia sumar: 2+4+6....+50");
            Console.WriteLine();

            Console.WriteLine("La sumatoria es: ");
            Console.WriteLine();


            int contador = 2;

            int suma = 0;

            while (contador <= 100)
            {

                suma += contador;
                contador += 2;               
            }

            Console.WriteLine(suma);

            Console.WriteLine();

            

Console.WriteLine("6. Desarrollar un algoritmo que realice la sumatoria de los números enteros múltiplos de 5. Teniendo en cuenta los comprendidos entre 1 y 100. Esto indica que debería sumar: 5+10+15+20...+100.");



Console.WriteLine("La sumatoria es: ");
            Console.WriteLine();


            int contador1 = 5;

            int suma1 = 0;

            while (contador1 <= 100)
            {

                suma1 += contador1;
                contador1 += 5;               
            }

            Console.WriteLine(suma1);

            Console.WriteLine();




Console.WriteLine("7. Desarrolle un algoritmo que recorra con un ciclo los primeros 300 números enteros (es decir, los números del 0 al 300) y determine cuántos de ellos son impares, al final el algoritmo también deberá indicar su sumatoria: 1+3+5+7+....+299.");


/*
 . Primero que todo hay que hacer el ciclo

*/


 Console.WriteLine();

            Console.WriteLine("Los numeros impares del 1 al 300 es:");
            for (int ciclo300 = 0; ciclo300 <= 300; ciclo300++)

                if (ciclo300 % 2 != 0)
                {
                    Console.Write(ciclo300+", ");
                }
            Console.WriteLine();

            Console.WriteLine("La suma de los numeros impares del 1 al 300 es:");
            Console.WriteLine();

            int contador2 = 1;

            int suma2 = 0;

            while (contador2 <= 300)
            {
                if (contador2 % 2 != 1) //Tambien se puede escribir " (contador2 % 2 == 1) "
                {
                    suma2 += contador2;
                }

                contador2 += 1;                   //Declara operacion de sumatoria
            }
            Console.WriteLine(suma2);

            Console.WriteLine();
    


            Console.WriteLine("8. Implementar un algoritmo que a partir de los numeros del 100 al 1, permita determinar: ");
            Console.WriteLine("* Cuantos numeros estan entre el 50 y 66 ?");
            Console.WriteLine("* Cuantos son mayores de 79 ?");
            Console.WriteLine("* Cuantos son menores de 18 ?");
            Console.WriteLine();

        int numero=0;
        int entre=0;
        int mayor=0;
        int menor=0;
           
           
           for(int i6=0;i6<=100;i6++){ //Ciclo que determina el contador hasa 100

Console.Write(i6+", ");
           }

           for(int y=79;y<100;y++){ //Ciclo que determina mayores de 79
          
            mayor++; //Contador adicional, que imprime solo el ultimo numero del ciclo for
           }

           
            for(int x=1;x<18;x++){   //Ciclo que determina menores de 18     
            
            menor++; //Contador adicional, que imprime solo el ultimo numero del ciclo for
            
        }

            
            for(int z=50;z<66;z++){ //Ciclo que determina Cuantos numeros estan entre el 50 y 66 
          
            entre++; //Contador adicional, que imprime solo el ultimo numero del ciclo for
            
        }
        
Console.WriteLine("");
Console.WriteLine("");

        Console.WriteLine("Hay "+(mayor)+"  numeros mayores que 79");
        Console.WriteLine("Hay "+(menor)+"  numeros menores que 18");
        Console.WriteLine("Hay "+(entre)+"  50 y 66");
        
                

                //9.

            //Leer una palabra por teclado y decir si es palindroma o no.

            Console.WriteLine();


            Console.WriteLine("9. Leer una palabra por teclado y decir si es palindroma o no.");

            Console.WriteLine();

            Console.WriteLine("Introduce una palabra");

            Boolean palindroma = true;

            string Palabra = new string(Console.ReadLine().ToCharArray());

            
 for (int Contt = 0; Contt < Palabra.Length; Contt++)
            {
                if (Palabra[Contt] != Palabra[Palabra.Length - Contt - 1])

                    palindroma = false;
            }


            Console.WriteLine(palindroma.ToString());

            if (palindroma == true)

            {

                Console.WriteLine("Es palindroma");
            }

            else
            {
                Console.WriteLine("No es palindroma");

            }
